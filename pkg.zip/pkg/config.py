
class Config:
     APP_NAME='New Year App'

class LiveConfig(Config):
     DBNAME='dtfdt'
     DBPWD='hvwgwcfc'

class TestConfig(Config):
     DBNAME='sdfsdvgfgv'
     DBPWD='bhvdhvvdhbhbvhvb'